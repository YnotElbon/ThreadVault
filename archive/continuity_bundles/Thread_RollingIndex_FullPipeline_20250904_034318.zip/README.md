# Rolling Index – Full Pipeline
This bundle contains the GitHub Action and the companion Python tool to auto-generate the continuity index.

## Place these files:
- `.github/workflows/rolling-index.yml`
- `tools/generate_index.py` (executable)

## How it works
- On each push (or manual run), the Action runs `tools/generate_index.py` against `ThreadVault/archives/` and writes the index to `ThreadVault/index/`.
- The Action auto-commits the refreshed index back to the repo.

## Local test
```bash
python3 tools/generate_index.py --dir ThreadVault/archives --out ThreadVault/index
```

## Optional: Git LFS for big ZIPs
```
git lfs install
git lfs track "ThreadVault/archives/*.zip"
git add .gitattributes
git commit -m "chore: enable LFS for archives"
```
