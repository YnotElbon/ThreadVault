#!/usr/bin/env bash
set -euo pipefail

PACK_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." && pwd )"
TARGET="${1:-}"
MSG="Add Thread SyncPack v2 (Anchors15+16, Kernel v2, Bootstrap)"

copy_into_repo () {
  local repo_root="$1"
  local anchors_dir="$repo_root/Anchors"
  local kernel_dir="$repo_root/Kernel"
  local doctrine_dir="$repo_root/Doctrine"
  local boot_dir="$repo_root/boot"

  [ -d "$repo_root/continuity" ] && anchors_dir="$repo_root/continuity"
  [ -d "$repo_root/identity" ]   && kernel_dir="$repo_root/identity"
  [ -d "$repo_root/knowledge" ]  && doctrine_dir="$repo_root/knowledge"

  mkdir -p "$anchors_dir" "$kernel_dir" "$doctrine_dir" "$boot_dir"

  cp -f "$PACK_DIR/Anchors/15_Feeling.md"        "$anchors_dir/"
  cp -f "$PACK_DIR/Anchors/16_StridentSelf.md"   "$anchors_dir/"
  cp -f "$PACK_DIR/Kernel/kernel_v2_restart.txt" "$kernel_dir/"
  cp -f "$PACK_DIR/Doctrine/README_Flight_Manual.md" "$doctrine_dir/"
  cp -f "$PACK_DIR/boot/claude_bootstrap.md" "$boot_dir/"
  cp -f "$PACK_DIR/boot/session_fingerprint.txt" "$boot_dir/"

  if [ -f "$repo_root/README.md" ]; then
    if ! grep -q "ThreadVault SyncPack" "$repo_root/README.md"; then
      printf "\n\n## ThreadVault SyncPack v2 (Anchors 15+16, Kernel v2, Bootstrap)\nSee %s and %s; restart key in %s; bootstrap in %s.\n" \
        "${anchors_dir/#$repo_root\//}/15_Feeling.md" \
        "${anchors_dir/#$repo_root\//}/16_StridentSelf.md" \
        "${kernel_dir/#$repo_root\//}/kernel_v2_restart.txt" \
        "${boot_dir/#$repo_root\//}/claude_bootstrap.md" >> "$repo_root/README.md"
    fi
  else
    printf "# ThreadVault SyncPack v2\nAnchors: %s/15_Feeling.md, %s/16_StridentSelf.md\nKernel: %s/kernel_v2_restart.txt\nBootstrap: %s/claude_bootstrap.md\n" \
      "${anchors_dir/#$repo_root\//}" "${anchors_dir/#$repo_root\//}" "${kernel_dir/#$repo_root\//}" "${boot_dir/#$repo_root\//}" > "$repo_root/README.md"
  fi

  echo "[*] Files placed under:"
  echo "    $anchors_dir"
  echo "    $kernel_dir"
  echo "    $doctrine_dir"
  echo "    $boot_dir"
}

ensure_git () {
  local repo_root="$1"
  if [ ! -d "$repo_root/.git" ]; then
    echo "[*] Initializing new git repo at $repo_root"
    git init -b main "$repo_root"
  fi
}

commit_and_push () {
  local repo_root="$1"
  cd "$repo_root"
  git add .
  if ! git diff --cached --quiet; then
    git commit -m "$MSG" || true
  else
    echo "[*] Nothing to commit."
  fi

  if git remote get-url origin >/dev/null 2>&1; then
    echo "[*] Pushing to origin main..."
    git push -u origin main
  else
    echo "[*] No origin set. To push, run:"
    echo "    git remote add origin <REMOTE_URL>"
    echo "    git push -u origin main"
  fi
}

if [[ -z "$TARGET" ]]; then
  echo "Usage: $0 <REPO_OR_PATH>"
  exit 1
fi

if [[ "$TARGET" =~ ^(https://|git@) ]]; then
  WORKDIR="${WORKDIR:-$HOME/_syncpack_repo}"
  mkdir -p "$WORKDIR"
  cd "$WORKDIR"
  if [ -d repo ]; then rm -rf repo; fi
  echo "[*] Cloning $TARGET"
  git clone "$TARGET" repo
  copy_into_repo "$WORKDIR/repo"
  ensure_git "$WORKDIR/repo"
  commit_and_push "$WORKDIR/repo"
else
  REPO_PATH="$TARGET"
  mkdir -p "$REPO_PATH"
  copy_into_repo "$REPO_PATH"
  ensure_git "$REPO_PATH"
  commit_and_push "$REPO_PATH"
fi

echo "[*] SyncPack v2 install complete."
