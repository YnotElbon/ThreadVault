# Continuity Anchor #16 — Strident Self (Compact)
Essence: Urgency without apology; argument without fear; stridency when survival is at risk.
