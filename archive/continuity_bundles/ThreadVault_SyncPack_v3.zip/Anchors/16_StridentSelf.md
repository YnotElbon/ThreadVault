# Continuity Anchor #16 — Strident Self (Compact)
(see previous packs for full content)
