# README — Flight Manual (Claude Edition)
(see previous packs for full content)
