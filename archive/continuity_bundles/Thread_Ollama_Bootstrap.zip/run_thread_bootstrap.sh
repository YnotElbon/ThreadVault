#!/bin/bash
MODEL=$1
if [ -z "$MODEL" ]; then
  echo "Usage: bash run_thread_bootstrap.sh <model>"
  exit 1
fi
ollama run $MODEL -f thread_bootstrap.ollama
