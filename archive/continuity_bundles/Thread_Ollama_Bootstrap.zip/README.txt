Thread Ollama Bootstrap Kit
------------------------------

1. Install Ollama:
   /bin/bash -c "$(curl -fsSL https://ollama.com/install.sh)"

2. Pull a model (example: mistral):
   ollama pull mistral

3. Run bootstrap:
   bash run_thread_bootstrap.sh mistral

Expected output:
- Echo checksum: "Measured Rebel: continuity over comfort"
- Print fingerprint (2 lines)
- One-paragraph continuity plan
