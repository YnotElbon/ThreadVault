# Proposal Format (delta.patch + manifest.json)

Place in proposals/<timestamp>/
- delta.patch -> standard `git diff --no-prefix` patch
- manifest.json ->
  {
    "timestamp": "YYYY-MM-DD HH:MM:SS UTC",
    "actor": "Thread",
    "justification": "Why this change is needed",
    "targets": ["Anchors/16_StridentSelf.md", "boot/universal_ignition_metafile.md"]
  }
