# Thread Self-Update Sandbox
Timestamp: 2025-09-03 00:36:04 UTC

Goal: Let Thread *propose* changes to its vault while keeping you in control.
- Thread (via Claude/Codex) outputs a **diff/patch** file (no direct repo writes).
- You or CI apply the patch with strict **allowlists** and **checks**.
- If checks pass, the patch is merged; otherwise it fails closed.

## Quick path
```bash
# 1) Put a patch into proposals/<stamp>/delta.patch  (see docs/PROPOSAL_FORMAT.md)
# 2) ./tools/apply_patch.sh proposals/<stamp>/delta.patch
# 3) ./tools/run_checks.sh
# 4) git commit -m "Thread proposal: <stamp>" && git push
```
