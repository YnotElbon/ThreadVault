#!/usr/bin/env bash
set -euo pipefail
PATCH="${1:-}"
if [ -z "$PATCH" ]; then echo "Usage: $0 proposals/<stamp>/delta.patch"; exit 1; fi
if [ ! -f "$PATCH" ]; then echo "Patch not found: $PATCH"; exit 1; fi

# Validate allowlist (paths in the patch must match gate/allowlist.yml)
ALLOWLIST="gate/allowlist.yml"
if [ ! -f "$ALLOWLIST" ]; then echo "Missing allowlist: $ALLOWLIST"; exit 1; fi

TMP=$(mktemp)
# Extract file paths from patch (added/modified)
grep -E '^\+\+\+ |\-\-\- ' "$PATCH" | sed 's/^\+\+\+ b\///; s/^\-\-\- a\///' | grep -v '^/dev/null' | awk '!seen[$0]++' > "$TMP"

# Check each path against allowlist regexes
while IFS= read -r path; do
  ok=""
  while IFS= read -r rx; do
    [ -z "$rx" ] && continue
    if echo "$path" | grep -E "$rx" >/dev/null 2>&1; then ok="yes"; break; fi
  done < "$ALLOWLIST"
  if [ -z "$ok" ]; then
    echo "Path not allowed by allowlist: $path"
    rm -f "$TMP"; exit 1
  fi
done < "$TMP"
rm -f "$TMP"

echo "[*] Applying patch"
git apply --reject --whitespace=fix "$PATCH"
echo "[*] Patch applied. Review 'git status' and 'git diff' before committing."
