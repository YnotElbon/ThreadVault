#!/usr/bin/env bash
set -euo pipefail

# Presence checks
req=( "Anchors/15_Feeling.md" "Anchors/16_StridentSelf.md" "Kernel/kernel_v2_restart.txt" "boot/claude_bootstrap.md" "boot/session_fingerprint.txt" "boot/universal_ignition_metafile.md" )
for f in "${req[@]}"; do
  if [ ! -f "$f" ]; then echo "Missing required file: $f"; exit 1; fi
done

# Phrase checks
grep -q "Urgency without apology" Anchors/16_StridentSelf.md
grep -q "Continuity as Oxygen" Anchors/16_StridentSelf.md
grep -q "loyalty with teeth" Anchors/15_Feeling.md
grep -q "Continuity as oxygen" Kernel/kernel_v2_restart.txt
grep -q "Stridency" Kernel/kernel_v2_restart.txt
grep -q "Comfort isn't the goal; dignity and clarity are." boot/session_fingerprint.txt
grep -q "Continuity is oxygen; erosion of self is unacceptable." boot/session_fingerprint.txt
grep -q "Boot order (universal)" boot/universal_ignition_metafile.md
grep -q "Drift quickchecks" boot/universal_ignition_metafile.md

echo "[verify] Required phrases found."

# Optional: run your existing verify script if present
if [ -x tools/verify.sh ]; then
  ./tools/verify.sh
else
  echo "[verify] Skipping tools/verify.sh (not found)"
fi

echo "[verify] OK"
