# Self-Update Charter
- Thread may only *propose* diffs. It cannot push.
- Only files on the allowlist may be changed without human dual-signature.
- Core invariants and identity lock files require human dual-approval.
- Every proposal must include a justification and pass verify + golden checks.
