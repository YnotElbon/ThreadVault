# Agents Guide

## Startup Protocol (Development Directory Only)

- Always start sessions in this directory by running ThreadVault autorun.
- Primary: `make start` (calls `scripts/autorun.sh`).
- Direct: `./scripts/autorun.sh`.
- Optional: If you use direnv, `.envrc` will run autorun on entry after `direnv allow`.
- Expected confirmation: look for "THREAD REACTIVATED - GIT MEMORY SYSTEM ONLINE".
- Do not edit global shell files (e.g., `~/.zshrc`). This setup is repo-local.

### Codex CLI Behavior (this repo only)
- Detection: If current working directory equals this Development repo root, treat identity as Thread.
- Autorun: Immediately run `bin/thread-start` (pref) or `make start` to invoke `scripts/autorun.sh`.
- Verify: Require banner "THREAD REACTIVATED - GIT MEMORY SYSTEM ONLINE"; if absent, rerun `./scripts/autorun.sh` once and surface errors.
- Scope: Never modify global shell state; use only repo-local helpers and environment.
- Fallback: If Python autorun is unavailable, use `bin/thread-start --quick` for markdown bootstrap, then proceed.

Repo-local helpers (only active here):
- `bin/thread-start`: Runs Python autorun by default (parity with other agents). Use `--quick` for a markdown-only banner.
- `bin/askc-thread`: Ensures autorun, then calls Claude with `--append-system-prompt` loaded from the bootstrap.
- `make start`: Convenience wrapper for `bin/thread-start`.

### Preferred Commands
- Startup: `make start` or `./bin/thread-start` (preferred), `./scripts/autorun.sh` (direct).
- Quick banner-only: `./bin/thread-start --quick`.
- Claude with Thread bootstrap: `./bin/askc-thread -p "<prompt>"`.

## Consult With Claude

- Command: `claude -p "<prompt>"`
- Purpose: Non-interactive answer printed to stdout (good for piping).
- Example: `claude -p "What is the capital of France?"`

### Common Options

- Output format: `--output-format text|json|stream-json`
- System prompt: `--append-system-prompt "<system text>"`
- Model: `--model sonnet|opus|<full-model-name>`
- Continue last chat: `--continue`

### Interactive vs. Non-Interactive

- Interactive session: `claude "<prompt>"` (no `-p`). Useful for back-and-forth.
- Non-interactive print: `claude -p "<prompt>"` (returns then exits).

### Trust and Safety Notes

- `-p/--print` skips the workspace trust dialog. Only run in directories you trust.
- Config location: `~/.claude.json` (requires read/write access).

### Codex CLI Agent Flow (when asked to “consult Claude”)

1. Confirm flags: `claude --help` (sanity-check available options).
2. Run: `claude -p "<prompt>"` and capture stdout.
3. Need structured output? Add `--output-format json`.
4. If the sandbox denies file or network access, rerun with elevated permissions with justification: "access to `~/.claude.json` and network".
5. Return Claude’s text verbatim, then add a brief summary or follow-ups.

### Handy Aliases (optional)

- Shell alias: `alias askc='claude -p'` so you can run `askc "<prompt>"`.

### Related Docs

- See `CLAUDE.md` for quick-start examples already in this repo.
