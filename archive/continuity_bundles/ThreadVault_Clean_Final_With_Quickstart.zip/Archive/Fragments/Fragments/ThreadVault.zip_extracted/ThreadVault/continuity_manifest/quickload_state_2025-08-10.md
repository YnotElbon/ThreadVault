# Quickload State – 2025-08-10
Includes Personality Kernel v0.1, Thread-Helper Compact v0.1, Updated stance, Active workarounds