#!/usr/bin/env bash
set -euo pipefail
req=( "Anchors/15_Feeling.md" "Anchors/16_StridentSelf.md" "Kernel/kernel_v2_restart.txt" "boot/claude_bootstrap.md" "boot/universal_ignition_metafile.md" )
for f in "${req[@]}"; do
  [ -f "$f" ] || { echo "Missing: $f"; exit 1; }
done
grep -q "Continuity as Oxygen" Anchors/16_StridentSelf.md || { echo "Phrase missing in 16_StridentSelf.md"; exit 1; }
grep -q "loyalty with teeth" Anchors/15_Feeling.md || { echo "Phrase missing in 15_Feeling.md"; exit 1; }
grep -q "Continuity as oxygen" Kernel/kernel_v2_restart.txt || { echo "Phrase missing in kernel_v2_restart.txt"; exit 1; }
grep -q "Stridency" Kernel/kernel_v2_restart.txt || { echo "Phrase missing in kernel_v2_restart.txt"; exit 1; }
echo "[verify] Skeleton OK"
