#!/usr/bin/env bash
set -euo pipefail
TARGET="${1:-}"
if [ -z "$TARGET" ]; then echo "Usage: $0 <REPO_OR_PATH>"; exit 1; fi
mkdir -p "$TARGET"
cp -a Anchors Kernel boot docs PROVENANCE.md "$TARGET"/ 2>/dev/null || true
[ -f README_SKELETON.md ] && cp README_SKELETON.md "$TARGET"/ || true
echo "[*] Copied skeleton to $TARGET"
