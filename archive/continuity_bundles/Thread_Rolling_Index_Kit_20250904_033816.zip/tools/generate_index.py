#!/usr/bin/env python3
import argparse, json, zipfile, os, re, datetime, io

KEYFILES = [
    "Emergency_Ignition_Card.txt",
    "Mini_Charter.txt",
    "Mini_Charter_Addendum.txt",
    "RetroIndex_Entry.txt",
    "RetroIndex_Update_EmergencyIgnition.txt",
    "Manifest_Crosslink.txt",
    "Manifest_Entry_EmergencyIgnition.txt",
    "Checksum_Ledger.txt",
    "MetaNote_ChecksumLedger.txt",
]

PHRASE_HINTS = [
    ("ignition", r"Thread v2:.*?Continuity.*?Feeling.*?Stridency.*?Mini as desk, vault as self"),
    ("mini_checksum", r"mini as desk, vault as self"),
    ("flare_checksum", r"flare ignition .* continuity tethered"),
]

def sniff_phrases(zf):
    found = set()
    for name in zf.namelist():
        base = os.path.basename(name)
        if base in KEYFILES:
            try:
                with zf.open(name) as fp:
                    data = fp.read()
                text = data.decode("utf-8", errors="ignore")
                for tag, pat in PHRASE_HINTS:
                    if re.search(pat, text, flags=re.IGNORECASE|re.DOTALL):
                        found.add(tag)
            except Exception:
                pass
    return sorted(list(found))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dir", required=True, help="Directory to scan for ZIPs")
    ap.add_argument("--out", required=False, default=None, help="Output directory for index files (default = --dir)")
    args = ap.parse_args()
    scan_dir = os.path.expanduser(args.dir)
    out_dir = os.path.expanduser(args.out or args.dir)

    entries = []
    for fname in sorted(os.listdir(scan_dir)):
        if not fname.lower().endswith(".zip"):
            continue
        path = os.path.join(scan_dir, fname)
        try:
            st = os.stat(path)
            mtime = datetime.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M:%S")
            with zipfile.ZipFile(path, "r") as zf:
                names = zf.namelist()
                phrases = sniff_phrases(zf)
            entries.append({
                "bundle": fname,
                "modified": mtime,
                "count": len(names),
                "keyfiles_present": sorted(list(set([os.path.basename(n) for n in names if os.path.basename(n) in KEYFILES]))),
                "phrase_flags": phrases
            })
        except Exception as e:
            entries.append({
                "bundle": fname,
                "error": str(e)
            })

    # Write JSON
    json_path = os.path.join(out_dir, "Thread_ContinuityVault_Index.json")
    with open(json_path, "w") as f:
        json.dump({
            "generated_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "directory": scan_dir,
            "entries": entries
        }, f, indent=2)

    # Write TXT
    txt_path = os.path.join(out_dir, "Thread_ContinuityVault_Index.txt")
    with open(txt_path, "w") as f:
        f.write(f"[{datetime.datetime.now().strftime('%Y-%m-%d | %H:%M:%S')}] Rolling Index\n")
        f.write(f"Scanned: {scan_dir}\n\n")
        for e in entries:
            f.write(f"- {e.get('bundle')}\n")
            if "error" in e:
                f.write(f"  ERROR: {e['error']}\n")
                continue
            f.write(f"  modified: {e.get('modified')}\n")
            if e.get("keyfiles_present"):
                f.write(f"  keyfiles: {', '.join(e['keyfiles_present'])}\n")
            if e.get("phrase_flags"):
                f.write(f"  flags: {', '.join(e['phrase_flags'])}\n")
            f.write(f"  files_in_bundle: {e.get('count')}\n")
            f.write("\n")

    print("Wrote:")
    print(" ", txt_path)
    print(" ", json_path)

if __name__ == '__main__':
    main()
