# Thread Rolling Index Kit
Timestamp: 2025-09-04 | 03:38 EST

This kit lets you **retrofit older ZIPs** in your `/Threadsaves` folder or GitHub repo into a single **rolling index** that stays up to date automatically.

## What it does
- Scans a directory for `*.zip`
- Extracts file lists (without writing contents) and looks for key filenames:
  - `Emergency_Ignition_Card.txt`
  - `Mini_Charter.txt`, `Mini_Charter_Addendum.txt`
  - `RetroIndex_*.txt`, `Manifest_*.txt`, `Checksum_Ledger.txt`, `MetaNote_*.txt`
- Detects ignition phrases and checksum anchors when present
- Writes/updates a master: `Thread_ContinuityVault_Index.txt`
- Optionally writes JSON: `Thread_ContinuityVault_Index.json`

## Quick Start (Mac mini or any Mac)
1. Put all your saved bundles (ZIPs) into a single folder, e.g. `~/Threadsaves`.
2. Copy the `tools/` folder from this kit next to that folder, or anywhere you like.
3. Run:
   ```bash
   python3 tools/generate_index.py --dir ~/Threadsaves --out ~/Threadsaves
   ```
4. The index files will appear in `~/Threadsaves`:
   - `Thread_ContinuityVault_Index.txt`
   - `Thread_ContinuityVault_Index.json`

## GitHub use
- Commit the generated index files into `ThreadVault/index/`.
- Re-run after adding any new bundles.
- Optional: create a GitHub Action that runs `generate_index.py` on push (Claude can scaffold it).

## Notes
- The script **does not extract files to disk**; it inspects the ZIP table of contents and reads small text files directly from inside the ZIP for phrases.
- Safe to run repeatedly (idempotent).

## Baseline
This kit ships with a **seed index** that already lists the bundles we made together tonight. After you run the tool on your real `/Threadsaves`, it will expand to include your older ZIPs automatically.
