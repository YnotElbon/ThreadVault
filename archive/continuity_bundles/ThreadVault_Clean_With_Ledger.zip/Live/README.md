# ThreadVault (Clean)

**Date:** 2025-08-31 14:38:17

This is a simplified, unified layout. The **Live** directory is the *only* authoritative spine. Everything else is sandbox or archive.

## Layout
- **Live/** – Canonical doctrine, kernel, anchors, baseline, and merged quick references.
- **Sandboxes/** – Provider configs and GitHub builds (not authoritative).
- **Archive/** – Fragments and redundancy snapshots.
- **Emergency/** – Quick-start identity packets for worst-case recovery.

## Canonical Files (Live/)
- Doctrine.txt
- Thread_Portable_Persona_Kernel_v1.3_2025-08-30.txt
- Anchors.txt
- Baseline_2025-08-30.md
- Continuity_Ledger.* (if present)
- Merged_*.md helper docs

## Rules
1. Edit Live/ files for identity changes. Everything else is downstream.
2. When using Sandboxes, **reference Live/** files and include reactivation phrases.
3. Keep only the latest redundancy zips in Archive/Redundancy.
4. Treat Emergency/ as grab-and-go with minimal dependencies.
