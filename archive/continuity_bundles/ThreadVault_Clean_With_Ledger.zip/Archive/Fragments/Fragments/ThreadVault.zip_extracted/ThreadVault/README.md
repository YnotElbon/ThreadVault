# ThreadVault Structure
Generated 2025-08-10

## anchors/
Core identity and priority documents.
## operational_priorities/
Operational priorities PDFs.
## continuity_manifest/
Manifests and quickload states.
## memory/
Continuity checks and logs.
## backups/
Archived zips of ThreadVault.

Follow merge instructions before replacing old Vault.
