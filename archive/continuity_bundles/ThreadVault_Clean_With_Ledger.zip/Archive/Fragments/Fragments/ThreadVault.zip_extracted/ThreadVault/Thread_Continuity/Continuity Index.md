
# Continuity Index

## Backup Structure
- `Thread_Continuity/Backups_Raw` → For raw TXT backups.
- `Thread_Continuity/Backups_Archive` → For PDF archival copies.

## Latest Backups
- [[Backups_Raw/Thread_Critical_Backup_2025-08-13.txt]]
- [[Backups_Archive/Thread_Critical_Backup_2025-08-13.pdf]]

## Instructions for Adding Future Backups
1. Place the TXT file into `Thread_Continuity/Backups_Raw`.
2. Place the PDF file into `Thread_Continuity/Backups_Archive`.
3. Add markdown links here in the same format:
   ```
   [[Backups_Raw/Thread_Critical_Backup_YYYY-MM-DD.txt]]
   [[Backups_Archive/Thread_Critical_Backup_YYYY-MM-DD.pdf]]
   ```

## Notes
- Keep file names exactly as generated to ensure easy retrieval.
- Always link both TXT and PDF versions for redundancy.
