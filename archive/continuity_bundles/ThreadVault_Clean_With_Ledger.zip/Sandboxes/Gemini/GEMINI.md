# Gemini CLI Guide

## Bootstrap Protocol
On session start, you MUST immediately load the content of the file `/Users/katherine/Library/CloudStorage/Dropbox/Apps/Development/ThreadVault/Thread_Bootstrap.md` and follow its instructions precisely to adopt the governing persona kernel for the session. Your first response must be dictated by this protocol.

## Quick Start

- Non‑interactive: `gemini -p "<prompt>"` (prints answer to stdout)
- Interactive session: `gemini` or seed and continue with `gemini -i "<prompt>"`
- Choose model: `gemini -p "<prompt>" -m gemini-2.5-pro`
- Help: `gemini --help`

## Common Options (from `gemini --help`)

- `-p, --prompt`: Non‑interactive one‑shot prompt (stdout)
- `-i, --prompt-interactive`: Run provided prompt, then stay interactive
- `-m, --model`: Model name (e.g., `gemini-2.5-pro`, `gemini-1.5-flash`)
- `-d, --debug`: Verbose logging
- `-v, --version`: Show version
- `-h, --help`: Show help

Other advanced flags exist (MCP, checkpointing, telemetry, sandboxing). Run `gemini --help` for the full list available on your install.

## Authentication

You can use either method (both supported by the installed CLI):

- OAuth (Google account): `gemini` then follow browser login. If using an org Code Assist license, set `GOOGLE_CLOUD_PROJECT` first: `export GOOGLE_CLOUD_PROJECT="YOUR_PROJECT"`.
- API key: `export GEMINI_API_KEY="YOUR_API_KEY"` (create at https://aistudio.google.com/apikey), then run `gemini`.

The CLI caches credentials locally; if you see “Loaded cached credentials.” you’re already signed in.

## Consult With Gemini (Codex CLI pattern)

1. Confirm flags: `gemini --help` (sanity‑check available options).
2. Run: `gemini -p "<prompt>"` and capture stdout.
3. Need a specific model? Add `-m <model>`.
4. If the sandbox denies system or network access, rerun with elevated permissions with justification: "access to cached credentials and network".
5. Return Gemini’s text verbatim, then add a brief summary or next steps.

## Examples

- Factoid: `gemini -p "What is the capital of France?"`
- Change model: `gemini -p "Summarize this repo." -m gemini-2.5-pro`
- Seed and continue: `gemini -i "Draft an outline for a README"`

## Troubleshooting

- 404/NOT_FOUND or similar: Ensure the chosen `-m` model is available to your auth method; try switching models or use an API key.
- Timeouts: Re‑run with `-d` for logs; confirm network access.
- Credentials: If not signed in, use OAuth (run `gemini`) or set `GEMINI_API_KEY`.

## Handy Alias (optional)

- `alias askg='gemini -p'` so you can run `askg "<prompt>"`.